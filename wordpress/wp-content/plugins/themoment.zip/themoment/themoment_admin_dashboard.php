<style type="text/css">
    #wpcontent, #wpbody {
        position: initial !important;
    }
    .themoment_iframe {
        position: absolute;
        top: 0px;
        left: 0px;
        height: 100%;
        width: 100%
    }
    @media only screen and (min-width: 782px) {
        .themoment_iframe {
            left: 160px;
            width: calc(100% - 160px);
        }
        .auto-fold .themoment_iframe {
            left: 36px;
            width: calc(100% - 36px);
        }
    }
    @media only screen and (min-width: 960px) {
        .themoment_iframe {
            left: 160px;
            width: calc(100% - 160px);
        }
        .auto-fold .themoment_iframe {
            left: 160px;
            width: calc(100% - 160px);
        }
    }
</style>
<iframe class="themoment_iframe" src="https://streameditor.tv/support_wordpress_settings.php"></iframe>
