<?php
//$themoment_script = 'http://localhost/moment_project/moment_app/output/ext/themoment.js';
$themoment_script = 'https://app-dev.themoment.tv/wordpress/themoment.js';